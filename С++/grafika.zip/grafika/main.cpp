#include <graphics.h>
#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
initwindow(800,600);
bar(50,50,100,100);
getch();
closegraph();
}
