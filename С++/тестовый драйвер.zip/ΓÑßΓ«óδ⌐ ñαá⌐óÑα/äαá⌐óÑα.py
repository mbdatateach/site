from tkinter import *
from tkinter import messagebox
from tkinter import font
import tkinter as tk
import subprocess
from subprocess import Popen, PIPE, STDOUT
import random
from tkinter.messagebox import showinfo

root = 0
test_array = []
answer = []
result_array=[]
points_arena=0
message_button_start=0
message_button_dalee=0
message_button_del=0
flag_stop=0
primers=[]

class Window(Tk):
    def __init__(self, *arg, **kwarg):
        super().__init__(*arg, **kwarg)
        self.title('Описание')
        self.attributes('-toolwindow', True)
        labelExample = Label(self, text = """Имя модуля должно содержать название той программы, которую необходимо протестировать.
        Программа должна быть передана в EXE файле и реализовывать консольный интерфейс.
        В поле ИМЯ МОДУЛЯ необходимо указать полный путь к файлу.""")
        labelExample.pack()

def justify_text(text, width):  
    # Разбиваем текст на строки  
    lines = text.split('\n')  
    justified_lines = []   
    for line in lines:  
        words = line.split()  
        if not words:  
            justified_lines.append('')  
            continue  
        # Если слово длиннее ширины, оставляем как есть  
        if len(max(words, key=len)) > width:  
            justified_lines.append(line)  
            continue    
        while words:  
            current_line = []  
            current_length = 0  
            # Собираем слова в строку  
            while words and current_length + len(words[0]) + len(current_line) <= width:  
                current_line.append(words.pop(0))  
                current_length += len(current_line[-1])  
            # Если это последняя строка или только одно слово - выравниваем слева  
            if len(current_line) == 1 or not words:  
                justified_lines.append(' '.join(current_line))  
                continue      
            # Вычисляем количество пробелов  
            total_spaces = width - current_length  
            num_gaps = len(current_line) - 1  
            spaces_between = total_spaces // num_gaps  
            extra_spaces = total_spaces % num_gaps  
            # Формируем строку с учетом пробелов  
            justified_line = []  
            for i, word in enumerate(current_line):  
                justified_line.append(word)  
                if i < num_gaps:  
                    justified_line.append(' ' * (spaces_between + (1 if i < extra_spaces else 0)))      
            justified_lines.append(''.join(justified_line))  
    return '\n'.join(justified_lines)

def tests(number_task, progr_entry, text_results):
    global test_array,answer, result_array, points_arena
    global message_button_start,message_button_dalee
    global flag_stop
    flag_stop=0
    result_array=[]
    a=progr_entry.get()
    
    text_results.configure(state=NORMAL)
    text_results.delete(1.0, END+"-1c")
    text_results.configure(state=DISABLED)

    n,i = 0,1
    count_a=0
    for x in test_array:
        try:
            p = Popen([a], stdout=PIPE, stdin=PIPE, stderr=STDOUT)
            stdout, stderr = p.communicate(input=x)
            stdout = stdout.decode().strip('\r\n')
        except Exception as e:
            result_str='Ошибка: '+str(e)
            result_array.append((result_str,1))
            continue
        if(str(stdout) == answer[n]):
            count_a+=1
            result_array.append(("Успех",0))
            if(count_a==3):
                points_arena+=1
                flag_stop=1
        else: result_array.append(("Ошибка: Несоответсвие ответов",1))
        text_results.configure(state=NORMAL)
        text_results.delete(1.0, END+"-1c")
        n+=1
    for x in result_array:
        if (x[1]==0): label = Label(text=x[0], fg="green", bg="white", font=("Calibri", 14))
        else: label = Label(text=x[0], fg="red", bg="white", font=("Calibri", 14))
        text_results.window_create(INSERT, window=label)
        text_results.insert(float(i+1), "\n")
        i+=1
    text_results.configure(state=DISABLED)
    if(flag_stop): message_button_start["state"] = "disabled"
    message_button_dalee["state"] = "normal"
            
def help_window():          
    Window().mainloop()
    
def dalee(progr_entry, text_results, text_tests):
    global test_array,answer,result_array
    global message_button_start,message_button_dalee
    global primers,root
    f = open('Задания','r')
    lines=f.readlines()
    if(len(primers)==(len(lines)//3)):
        message_button_del["state"] = "normal"
        showinfo(title="Информация", message="""Вы прорешали все задания из файла и набрали """+ str(points_arena)+""" очков.
Дальше задания будут повторяться, так что можете закрыть это окно и добавить новые задания в файл.""")
        primers=[]
    else:
        result_array=[]
        text_results.configure(state=NORMAL)
        text_tests.configure(state=NORMAL)
        text_results.delete(1.0, END+"-1c")
        text_tests.delete(1.0, END+"-1c")
        text_results.configure(state=DISABLED)
        text_tests.configure(state=DISABLED)
        number_task=random.randint(0,(len(lines)//3)-1)
        if(number_task in primers):
            while(number_task in primers):
                number_task=random.randint(0,(len(lines)//3)-1)
        primers.append(number_task)
        print(number_task)
        task=lines[number_task*3].strip()
        test_array=lines[number_task*3+1].strip()
        answer=lines[number_task*3+2].strip()
        test_array = test_array.split('$')
        answer = answer.split('$')
        for i in range(len(test_array)): test_array[i]=test_array[i].encode().decode('unicode_escape').encode("raw_unicode_escape")
        for i in range(len(answer)): answer[i]=str(answer[i])
        f.close()
        label = Label(text=task, fg="black", bg="white", font=("Calibri", 16))
        text_tests.config(state=NORMAL)
        text_tests.insert("1.0", justify_text(task,50))
        text_tests.config(state=DISABLED)
        message_button_start["state"] = "normal"
        message_button_dalee["state"] = "disabled"

def newText(who,x):
    who.config(state="normal")
    who.delete(1.0,END)
    who.insert(END,x)
    who.config(state="disabled")
    
def del_root(root):
    try: root.destroy()
    except: print("Окно уже удалено")

def main():
    global root
    global test_array,answer,result_array,points_arena
    global message_button_start,message_button_dalee,message_button_del
    global flag_stop
    global primers
    result_array=[]
    points_arena=0
    flag_stop=0
    number_task=random.randint(0,9)
    if(number_task in primers):
        while(number_task in primers):
            number_task=random.randint(0,9)
    primers.append(number_task)
    root = Tk()
    root.geometry('420x500')
    root.title('Тестовый драйвер для языка C++')
    mainmenu = Menu(root) 
    root.config(menu=mainmenu)
    mainmenu.add_command(label='Справка', command=help_window)
    progr = StringVar()
    answer = StringVar()

    progr_label = Label(text="Имя модуля :")
    progr_label.grid(row=1, column=0, sticky="s")
    progr_label.config(font=("Calibri", 15))
    progr_entry = Entry(textvariable=progr)
    progr_entry.grid(row=1,column=1, sticky="w")

    progr_label = Label(text="Задание")
    progr_label.grid(row=2, column=0, sticky="w")
    progr_label.config(font=("Calibri", 15))
    text_tests = Text(width=50, height=12, wrap = WORD)
    text_tests.grid(row=3,column=0, columnspan=3, padx=5, pady=5)
    text_tests.configure(state=DISABLED)

    progr_label = Label(text="Результаты тестов")
    progr_label.grid(row=4, column=0, sticky="w")
    progr_label.config(font=("Calibri", 15))
    text_results = Text(width=50, height=8)
    text_results.grid(row=5,column=0, columnspan=3, padx=5, pady=5)
    text_results.configure(state=DISABLED)
    
    message_button_start = Button(text="Проверить решение", font=("Calibri", 15), command=lambda: tests(number_task, progr_entry, text_results))
    message_button_start.place(x=105, y=450)
    
    message_button_del = Button(text="Закрыть", font=("Calibri", 15), command=lambda: del_root(root))
    message_button_del.place(x=320, y=450)
    message_button_del["state"] = "disabled"

    message_button_dalee = Button(text="Далее", font=("Calibri", 15), command=lambda: dalee(progr_entry, text_results, text_tests))
    message_button_dalee.place(x=10, y=450)
    message_button_dalee["state"] = "disabled"
    f = open('Задания','r')
    lines=f.readlines()
    print(number_task)
    task=lines[number_task*3].strip()
    test_array=lines[number_task*3+1].strip()
    answer=lines[number_task*3+2].strip()
    test_array = test_array.split('$')
    answer = answer.split('$')
    for i in range(len(test_array)): test_array[i]=test_array[i].encode().decode('unicode_escape').encode("raw_unicode_escape")
    for i in range(len(answer)): answer[i]=str(answer[i])
    f.close()
    text_tests.config(state=NORMAL)
    text_tests.insert("1.0", justify_text(task,50))
    text_tests.config(state=DISABLED)
    root.mainloop()
    
if __name__ == '__main__':
    main()
