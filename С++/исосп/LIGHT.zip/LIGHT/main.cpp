#include<windows.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <cmath>
#include <stdio.h>
#include <iostream>

#define PI 3.14159265
static float rot_x=0, rot_y=0, tran=0;
static float rot_x_green=0, rot_y_green=0, tran_green=0;
static float rot_y_snowman=0;
static int material_choose=11;
static int light_sample = 1;

static int lightning_all=0,light0=0,light1=0,light2=0,light3=0,light4=0,light5=0,light6=0;

void choose(int choose_mater);


void DrawSun(float red, float green, float blue, float x, float y, float z, float rot_y,float rot_x,float tran_z)
{
    glPushMatrix();
    glDisable(GL_LIGHTING);
    //glDisable(GL_DEPTH_TEST);
        glColor3f(red,green,blue);
        glRotatef(rot_y, 0, 1, 0);
        glRotated(rot_x, 1, 0, 0);
        glTranslatef(x, y, z);
        glTranslatef(0, 0, tran_z);
        glutSolidCube(0.2);
    glEnable(GL_LIGHTING);
    //glEnable(GL_DEPTH_TEST);
    glPopMatrix();
}

void scene();
void DrawPlate(float red, float green, float blue){
    glLoadIdentity();
      // ���������
      GLfloat x, y;
      glBegin(GL_QUADS);
            glColor3f(red,green,blue);
            glNormal3f(0.0, 0.0, -1.0);
            for (x = -1.0; x < 1.0; x += 0.005)
            {
                  for (y = -1.0; y < 1.0; y += 0.005)
                  {
                        glVertex3f(x, y, 0.0);
                        glVertex3f(x, y + 0.005, 0.0);
                        glVertex3f(x + 0.005, y + 0.005, 0.0);
                        glVertex3f(x + 0.005, y, 0.0);
                  }
            }
        glEnd();

        glEnable(GL_COLOR_MATERIAL);
        scene();
        glDisable(GL_COLOR_MATERIAL);
}
void Circle(float size, float red, float green, float blue)
{
    glColor3f(red,green,blue);
	glutSolidSphere(size,20,20);  //������ �����
}

void Conus(float radius, float height, float red, float green, float blue)
{
    glColor3f(red,green,blue);
	glutSolidCone (radius, height, 20, 20);
}
float size_c,coef_sred,coef_mal,coef_conus,S;
void InitSnowMan(){
    S = 0.7;
    size_c = 0.3;
    coef_sred = 2;
    coef_mal = 8;
    coef_conus = 8;
}

void DrawSnowMan(){
    InitSnowMan();
    glPushMatrix(); //���������
    //glEnable(GL_COLOR_MATERIAL);
    Circle(size_c, 0,0,0.85);
    glTranslatef(0,size_c+size_c/coef_sred,0);
    Circle(size_c/coef_sred, 0,0,0.85);
    glTranslatef(-size_c/coef_mal,size_c/coef_mal,size_c/coef_sred);
    Circle(size_c/coef_mal, 0,0,0);
    glTranslatef((size_c/coef_mal)*2,0,0);
    Circle(size_c/coef_mal, 0,0,0);
    glTranslatef(-size_c/coef_mal,(-size_c/coef_conus)*2,0);
    Conus(size_c/coef_conus,size_c/coef_sred,1,0,0);
    //glDisable(GL_COLOR_MATERIAL);
	glPopMatrix(); //������������
}

// �������������
void init (void)
{
      glClearColor (0.3, 0.3, 0.3, 1.0);
      if(lightning_all==0) glEnable(GL_LIGHTING);
      glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
      glEnable(GL_NORMALIZE);
}

void reshape(int width, int height)
{
      glViewport(0, 0, width, height);
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      glOrtho(-1, 1, -1, 1, -5, 5);
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
}

float no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
float mat_ambient[] = { 0.7, 0.7, 0.7, 1.0 };
float mat_ambient_color[] = { 0.0, 0.8, 0.2, 1.0 };
float mat_diffuse[] = { 0.1, 0.5, 0.8, 1.0 };
//float mat_diffuse[] = { 0.7, 0.7, 0.7, 1.0 };
float mat_specular[] = { 0.6, 0.6, 0.6, 1.0 };
float no_shininess = 0.0;
float low_shininess = 5.0;
float high_shininess = 100.0;
float mat_emission[] = { 0.3, 0.2, 0.2, 0.0 };

void materia(int c) {
    switch (c)
    {
    case 1: // diffuse and specular reflection; low shininess; no ambient
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, no_mat);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 2:  // diffuse and specular reflection; high shininess; no ambient
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, mat_specular);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, low_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 3:
        // diffuse and specular reflection; high shininess; no ambient
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, mat_specular);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, high_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 4:
        // diffuse reflection; emission; no ambient or specular reflection
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, no_mat);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, no_mat);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, mat_emission);
        break;
    case 5:
        // ambient and diffuse reflection; no specular
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, no_mat);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 6:
        // ambient, diffuse and specular reflection; low shininess
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, mat_specular);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, 3);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 7:
        // ambient, diffuse and specular reflection; high shininess
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, mat_specular);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, high_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 8:
        // ambient and diffuse reflection; emission; no specular
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, no_mat);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, mat_emission);
        break;
    case 9:
        // colored ambient and diffuse reflection; no specular
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient_color);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, no_mat);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 10:
        // colored ambient, diffuse and specular reflection; low shininess
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient_color);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, mat_specular);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, low_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 11:
        // colored ambient, diffuse and specular reflection; high shininess
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient_color);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, mat_specular);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, high_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, no_mat);
        break;
    case 12:
        float fl[4];
        fl[0] = 0.7; fl[1] = 0.7; fl[2] = 0.7; fl[3] = 0;
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, fl);
        fl[0] = 0.7; fl[1] = 0.8; fl[2] = 0.7; fl[3] = 0;
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, fl);
        break;
    default:
        // colored ambient and diffuse reflection; emission; no specular
        glMaterialfv(GL_FRONT_AND_BACK , GL_AMBIENT, mat_ambient_color);
        glMaterialfv(GL_FRONT_AND_BACK , GL_DIFFUSE, mat_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK , GL_SPECULAR, no_mat);
        glMaterialf(GL_FRONT_AND_BACK , GL_SHININESS, no_shininess);
        glMaterialfv(GL_FRONT_AND_BACK , GL_EMISSION, mat_emission);
    }
}

void choose(int choose_mater){
    if(choose_mater==1) materia(1);
    else if(choose_mater==2) materia(2);
    else if(choose_mater==3) materia(3);
    else if(choose_mater==4) materia(4);
    else if(choose_mater==5) materia(5);
    else if(choose_mater==6) materia(6);
    else if(choose_mater==7) materia(7);
    else if(choose_mater==8) materia(8);
    else if(choose_mater==9) materia(9);
    else if(choose_mater==10) materia(10);
    else if(choose_mater==11) materia(11);
    else if(choose_mater==12) materia(12);
    else materia(1);
}
void scene(){// ����� ���� � ������
    InitSnowMan();
    glPushMatrix(); //���������
    glTranslatef(0,0,0.55);
    glRotatef(rot_y_snowman, 0, 1, 0);
    glTranslatef(-size_c, 0.0, 0.0);
    //choose(1);
	DrawSnowMan();
	glTranslatef(size_c, 0.0, 0.0);
	glScalef(S, S, S);
	glTranslatef(size_c, 0.0, 0.0);
    //choose(7);
	DrawSnowMan();
	glTranslatef(size_c , 0.0, 0.0);
	glScalef(S, S, S);
	glTranslatef(size_c , 0.0, 0.0);
    //choose(11);
	DrawSnowMan();
    glPopMatrix(); //������������
}
void display(void)
{
      init();
      glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      float mas0[]={0,0,0,0};
      float masNotGl0[]={1,1,1,1};
      //glLightModelfv(GL_LIGHT_MODEL_AMBIENT,mas0);

      //glEnable(GL_COLOR_MATERIAL);

      // ��������� ���������� �����
      if (light_sample == 1)
      {
            // ������������ �������� �����
            GLfloat light0_diffuse[] = {1.0, 1.0, 1.0};
            GLfloat light0_direction[] = {0.0, 0.0, 1.0, 0.0};
            if(light0==0) glEnable(GL_LIGHT0);
            glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
            glLightfv(GL_LIGHT0, GL_POSITION, light0_direction);
      }
      else if (light_sample == 2)
      {
            // �������� �������� �����
            // �������� ������������� � �����������
            // ��������� (�� ���������)
            GLfloat light1_diffuse[] = {1.0, 1.0, 1.0};
            GLfloat light1_position[] = {0.0, 0.0, 1.0, 1.0};
            if(light1==0) glEnable(GL_LIGHT1);
            glLightfv(GL_LIGHT1, GL_SPECULAR, masNotGl0);
            glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse);
            glLightfv(GL_LIGHT1, GL_POSITION, light1_position);
      }

      else if (light_sample == 3)
      {
            // �������� �������� �����
            // �������� ������������� � �����������
            // ������ �������� f(d) = 1.0 / (0.4 * d * d + 0.2 * d)
            GLfloat light2_diffuse[] = {1.0, 1.0, 1.0};
            GLfloat light2_position[] = {0.0, 0.0, 1.0, 1.0};
            if(light2==0) glEnable(GL_LIGHT2);
            glLightfv(GL_LIGHT2, GL_SPECULAR, masNotGl0);
            glLightfv(GL_LIGHT2, GL_DIFFUSE, light2_diffuse);
            glLightfv(GL_LIGHT2, GL_POSITION, light2_position);
            glLightf(GL_LIGHT2, GL_CONSTANT_ATTENUATION, 0.0);
            glLightf(GL_LIGHT2, GL_LINEAR_ATTENUATION, 0.2);
            glLightf(GL_LIGHT2, GL_QUADRATIC_ATTENUATION, 0.4);
      }

      else if (light_sample == 4)
      {
            // ���������
            // �������� ������������� � �����������
            // ��������� (�� ���������)
            // �������� ���� ��� ������� 30 ��������
            // ����������� �� ����� ���������
            GLfloat light3_diffuse[] = {1.0, 1.0, 1.0};
            GLfloat light3_position[] = {0.0, 0.0, 1.0, 1.0};
            GLfloat light3_spot_direction[] = {0.0, 0.0, -1.0};
            if(light3==0) glEnable(GL_LIGHT3);
            glLightfv(GL_LIGHT3, GL_SPECULAR, masNotGl0);
            glLightfv(GL_LIGHT3, GL_DIFFUSE, light3_diffuse);
            glLightfv(GL_LIGHT3, GL_POSITION, light3_position);
            glLightf(GL_LIGHT3, GL_SPOT_CUTOFF, 30);
            glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, light3_spot_direction);
      }
      else if (light_sample == 5)
      {
            // ���������
            // �������� ������������� � �����������
            // ��������� (�� ���������)
            // �������� ���� ��� ������� 30 ��������
            // ����������� �� ����� ���������
            // ������� ������� �������� ������������� ��� ����������
            GLfloat light4_diffuse[] = {1.0, 1.0, 1.0};
            GLfloat light4_position[] = {0.0, 0.0, 1.0, 1.0};
            GLfloat light4_spot_direction[] = {0.0, 0.0, -1.0};
            if(light4==0) glEnable(GL_LIGHT4);
            glLightfv(GL_LIGHT4, GL_SPECULAR, masNotGl0);
            glLightfv(GL_LIGHT4, GL_DIFFUSE, light4_diffuse);
            glLightfv(GL_LIGHT4, GL_POSITION, light4_position);
            glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, 30);
            glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, light4_spot_direction);
            glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 10.0);
      }
      else if (light_sample == 6)
      {
            // ��������� ���������� �����
            GLfloat light5_diffuse[] = {0.0, 1.0, 0.0};
            GLfloat light5_position[] = {0.0, 0, 1, 0};
            if(light5==0) glEnable(GL_LIGHT5);
            glLightfv(GL_LIGHT5, GL_SPECULAR, masNotGl0);
            glLightfv(GL_LIGHT5, GL_DIFFUSE, light5_diffuse);
            glLightfv(GL_LIGHT5, GL_POSITION, light5_position);
            glLoadIdentity();
            glRotatef(rot_y_green, 0, 1, 0);
            glRotated(rot_x_green, 1, 0, 0);
            glTranslatef(0, 0, tran_green);
            GLfloat light6_diffuse[] = {1.0, 1.0, 1.0};
            GLfloat light6_position[] = {0.5, 0, 1, 1};
            if(light6==0) glEnable(GL_LIGHT6);
            glLightfv(GL_LIGHT6, GL_SPECULAR, masNotGl0);
            glLightfv(GL_LIGHT6, GL_DIFFUSE, light6_diffuse);
            glLightfv(GL_LIGHT6, GL_POSITION, light6_position);
            glLightf(GL_LIGHT6, GL_CONSTANT_ATTENUATION, 0.0);
            glLightf(GL_LIGHT6, GL_LINEAR_ATTENUATION, 0.4);
            glLightf(GL_LIGHT6, GL_QUADRATIC_ATTENUATION, 0.8);
      }
        glLoadIdentity();
        glRotatef(rot_y, 0, 1, 0);
        glRotated(rot_x, 1, 0, 0);
        glTranslatef(0, 0, tran);

        glPushMatrix(); //���������
            choose(material_choose);
            DrawPlate(1,1,1);
            if(light_sample!=6) DrawSun(0.9,0.9,0.9, 0,0,1, rot_y,rot_x,tran);
            else {
                DrawSun(1,0,0, 0.0,0,1, rot_y,rot_x,tran);
                DrawSun(0,1,0, 0.5,0,1,  rot_y_green,rot_x_green,tran_green);
            }
        glPopMatrix(); //������������

      // ���������� ���������� �����
      glDisable(GL_LIGHT0);
      glDisable(GL_LIGHT1);
      glDisable(GL_LIGHT2);
      glDisable(GL_LIGHT3);
      glDisable(GL_LIGHT4);
      glDisable(GL_LIGHT5);
      glDisable(GL_LIGHT6);
      // ������� ������� �����������
      glutSwapBuffers();
}

void keyboard_function(unsigned char key, int x, int y)
{
      if (key == '1') light_sample = 1;
      if (key == '2') light_sample = 2;
      if (key == '3') light_sample = 3;
      if (key == '4') light_sample = 4;
      if (key == '5') light_sample = 5;
      if (key == '6') light_sample = 6;
    if (key == 'a') { rot_y -= 2.0; };
    if (key == 'd') { rot_y += 2.0; };
    if (key == 's') { tran += 0.1; };
    if (key == 'w') { tran -= 0.1; };
    if (key == 'z') { rot_x += 2; };
    if (key == 'c') { rot_x -= 2; };

    if (key == ',') { rot_x_green += 2; };
    if (key == '/') { rot_x_green -= 2; };
    if (key == '.') { rot_x_green = 0; rot_y_green = 0; tran_green=0;rot_y_snowman=0; };

    if (key == '[') { rot_y_snowman -= 2; };
    if (key == ']') { rot_y_snowman += 2; };

    if (key == 'x') { rot_x = 0; rot_y = 0; tran = 0;rot_y_snowman=0;};
    if (key == 'o') {
    if(light_sample == 1)
        if(light0==0) light0=1;
        else light0=0;
    if(light_sample == 2)
        if(light1==0) light1=1;
        else light1=0;
    if(light_sample == 3)
        if(light2==0) light2=1;
        else light2=0;
    if(light_sample == 4)
        if(light3==0) light3=1;
        else light3=0;
    if(light_sample == 5)
        if(light4==0) light4=1;
        else light4=0;
    if(light_sample == 6){
        if(light5==0) light5=1;
        else light5=0;
        }
    };
    if (key == 'i') {
        if(light6==0) light6=1;
        else light6=0;
    }
    if (key == 'p') {
        if(lightning_all==0) {
            glDisable(GL_LIGHTING);
            lightning_all=1;
        }
        else{
            glEnable(GL_LIGHTING);
            lightning_all=0;
        }
    };
      glutPostRedisplay();
}

void specialkeys(int key, int x, int y) {
    if (key == GLUT_KEY_F1) { material_choose=1; };
    if (key == GLUT_KEY_F2) { material_choose=2; };
    if (key == GLUT_KEY_F3) { material_choose=3; };
    if (key == GLUT_KEY_F4) { material_choose=4; };
    if (key == GLUT_KEY_F5) { material_choose=5; };
    if (key == GLUT_KEY_F6) { material_choose=6; };
    if (key == GLUT_KEY_F7) { material_choose=7; };
    if (key == GLUT_KEY_F8) { material_choose=8; };
    if (key == GLUT_KEY_F9) { material_choose=9; };
    if (key == GLUT_KEY_F10) { material_choose=10; };
    if (key == GLUT_KEY_F11) { material_choose=11; };
    if (key == GLUT_KEY_F12) { material_choose=12; };

    if (key == GLUT_KEY_LEFT) { rot_y_green-= 2.0; };
    if (key == GLUT_KEY_RIGHT) { rot_y_green+= 2.0; };
    if (key == GLUT_KEY_UP) { tran_green -= 0.1; };
    if (key == GLUT_KEY_DOWN) { tran_green += 0.1; };
    glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit (&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowPosition (50, 100);
    glutInitWindowSize (600, 600);
	glutCreateWindow("Our first GLUT application!");
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard_function);
    glutSpecialFunc(specialkeys);
	glutMainLoop();
	return 0;
}
