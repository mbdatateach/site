#include <Windows.h>
#include <windowsx.h>
#include <string>
#include <future>
#include <algorithm>
using std::string;
using std::to_string;
#define clBackgroundColor RGB(255,255,255)
#define clLineColor RGB(0, 0, 0)
#define clBoxLineColor RGB(0, 0, 255)
#define clRedColor RGB(255, 0, 0)
#define clCellColor RGB(255, 255, 255)


class Player{
    int myArea[10][10],  // ��������� ��������
        shootArea[10][10], // -1 - ������, 1 - ���������  // ���������� ��������� �������
        woundArea[10][10]; // -1 - ������, 1 - ��������� // �������� �� �����
    int X, Y, prevX, prevY;
    bool lastMove;
    int ships;
    bool Freedom(const int, const int, int [10][10]);
public:
    int counter;
    bool checkCell(int, int);
    int getShootCell(int, int);
    int getWoundCell(int, int);
    std::pair<int, int> shoot();
    int checkHit(int, int);
    void writeShoot(int);
    void genNew();
    bool gameOver();
    Player();
    ~Player();
};


bool Player::Freedom(const int x, const int y, int area[10][10]){
    int d[8][2] = {{0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,1},{1,-1},{-1,-1}};
    if((x >= 0)&&(x < 10)&&(y >= 0)&&(y < 10)&&(area[x][y] == 0)){
        for(int i=0;i<8;i++){
            int dx = x + d[i][0];
            int dy = y + d[i][1];
            if((dx >= 0)&&(dx < 10)&&(dy >= 0)&&(dy < 10)&&(area[dx][dy] > 0)) return false;
        }
        return true;
    }else return false;
}
Player::Player():X(0),Y(0),lastMove(false), ships(0){
    counter = 0;
    srand(static_cast<unsigned>(time(NULL)));
    for(int i=0;i<10;i++)
        for(int j=0;j<10;j++)
			shootArea[i][j] = myArea[i][j] = woundArea[i][j] = 0;
    bool b;
    for(int n=3;n>=0;n--){
        for(int m=0;m<=3-n;m++){
            do{
                int x = rand() % 10;
                int y = rand() % 10;
                int kx = rand() % 2; //0 - ����, �����; 1 - ����, ���
                int ky = (kx==0)?1:0;
                b = true;
                for(int i=0;i<=n;i++) if(!Freedom(x + kx * i, y + ky * i, myArea)) b = false;
                if(b) for(int i=0;i<=n;i++) myArea[x+kx*i][y+ky*i] = 1;
            }while(!b);
        }
    }
}
Player::~Player(){

}
bool Player::checkCell(int x, int y){
    return (myArea[x][y]==1);
}
int Player::getShootCell(int x, int y){
    return shootArea[x][y];
}
int Player::getWoundCell(int x, int y){
    return woundArea[x][y];
}
bool Player::gameOver(){
    if(ships==10) return true;
    for(int i=0;i<10;i++)
        for(int j=0;j<10;j++)
            if(shootArea[i][j]==0) return false;
    return true;
}
void Player::genNew(){
    srand(static_cast<unsigned>(time(NULL)));
    for(int i=0;i<10;i++)
        for(int j=0;j<10;j++)
			shootArea[i][j] = myArea[i][j] = 0;

    bool b;
    for(int n=3;n>=0;n--){
        for(int m=0;m<=3-n;m++){
            do{
                int x = rand() % 10;
                int y = rand() % 10;
                int kx = rand() % 2; //0 - ����, �����; 1 - ����, ���
                int ky = (kx==0)?1:0;
                b = true;
                for(int i=0;i<=n;i++) if(!Freedom(x + kx * i, y + ky * i, myArea)) b = false;
                if(b) for(int i=0;i<=n;i++) myArea[x+kx*i][y+ky*i] = 1;
            }while(!b);
        }
    }
}
std::pair<int, int> Player::shoot(){
    srand(static_cast<unsigned>(time(NULL)));
    counter++;
    if(lastMove){
        if(prevX==-1 && prevY==-1){
            int pos[4] = {0, 0, 0, 0}; // x-�����, x-������, y-�������, y-������
            if(shootArea[X-1][Y]==1) pos[0]++;
            if(shootArea[X+1][Y]==1) pos[1]++;
            if(shootArea[X][Y-1]==1) pos[2]++;
            if(shootArea[X][Y+1]==1) pos[3]++;

            prevX = X; prevY = Y;

            if(pos[0]==0 && X-1>=0 && X--) return std::make_pair(X, Y);
            if(pos[1]==0 && X+1<10 && X++) return std::make_pair(X, Y);
            if(pos[2]==0 && Y-1>=0 && Y--) return std::make_pair(X, Y);
            if(pos[3]==0 && Y+1<10 && Y++) return std::make_pair(X, Y);
            do{
                X = rand() % 10;
                Y = rand() % 10;
            }while(shootArea[X][Y]!=0);
            return std::make_pair(X, Y);
        }else{
            if(prevX==X){
                if(prevY<Y){
                    if(Y+1>=10){
                        Y = prevY-1;
                        if(shootArea[X][Y]==-1){
                            for(int &i=Y;i<10;i++) if(shootArea[X][Y]==0) break;
                            prevY = Y-1;
                        }
                        return std::make_pair(X, Y);
                    }else{
                        prevY = Y;
                        Y++;
                        if(shootArea[X][Y]==-1){
                            for(int &i=Y;i>=0;i--) if(shootArea[X][Y]==0) break;
                            prevY = Y+1;
                        }
                        return std::make_pair(X, Y);
                    }
                }else{
                    if(Y-1<0){
                        Y = prevY+1;
                        if(shootArea[X][Y]==-1){
                            for(int &i=Y;i>=0;i--) if(shootArea[X][Y]==0) break;
                            prevY = Y-1;
                        }
                        return std::make_pair(X, Y);
                    }else{
                        prevY = Y;
                        Y--;
                        if(shootArea[X][Y]==-1){
                            for(int &i=Y;i>=0;i++) if(shootArea[X][Y]==0) break;
                            prevY = Y+1;
                        }
                        return std::make_pair(X, Y);
                    }
                }
            }else{
                if(prevX<X){
                    if(X+1>=10){
                        X = prevX-1;
                        if(shootArea[X][Y]==-1){
                            for(int &i=X;i<10;i++) if(shootArea[X][Y]==0) break;
                            prevX = X-1;
                        }
                        return std::make_pair(X, Y);
                    }else{
                        prevX = X;
                        X++;
                        if(shootArea[X][Y]==-1){
                            for(int &i=X;i>=0;i--) if(shootArea[X][Y]==0) break;
                            prevX = X-1;
                        }
                        return std::make_pair(X, Y);
                    }
                }else{
                    if(X-1<0){
                        X = prevX+1;
                        if(shootArea[X][Y]==-1){
                            for(int &i=X;i>=0;i--) if(shootArea[X][Y]==0) break;
                            prevX = X-1;
                        }
                        return std::make_pair(X, Y);
                    }else{
                        prevX = X;
                        X--;
                        if(shootArea[X][Y]==-1){
                            for(int &i=X;i<10;i++) if(shootArea[X][Y]==0) break;
                            prevX = X-1;
                        }
                        return std::make_pair(X, Y);
                    }
                }
            }
        }
    }else{
        prevX = -1; prevY = -1;
        do{
            X = rand() % 10;
            Y = rand() % 10;
        }while(shootArea[X][Y]!=0);
        return std::make_pair(X, Y);
    }
}
int Player::checkHit(int x, int y){
    /* �������  0 - ������, 1 - �����, 2 - ���� */
    if(myArea[x][y]==1){
        woundArea[x][y] = 1;
        int xkl = (checkCell(x+1,y) || checkCell(x-1,y))?1:0,
            ykl = 1 - xkl,
            _x(x),
            _y(y),
            k(0), p(0);
        for(;checkCell(_x, _y);_x += xkl, _y += ykl){
            k++;
            if(woundArea[_x][_y]==1) p++;
        }
        for(_x=x,_y=y; checkCell(_x, _y); _x -= xkl, _y -= ykl){
            k++;
            if(woundArea[_x][_y]==1) p++;
        }
        if(k==p){
            int xkl = (woundArea[x+1][y]==1 || woundArea[x-1][y]==1?1:0),
                ykl = 1 - xkl,
                _x(x),
                _y(y),
                dx, dy,
                d[8][2] = {{0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,1},{1,-1},{-1,-1}};
            for(;woundArea[_x][_y]==1;_x += xkl, _y += ykl)
                for(int i=0;i<8;i++){
                    dx = _x + d[i][0];
                    dy = _y + d[i][1];
                    if((dx >= 0)&&(dx < 10)&&(dy >= 0)&&(dy < 10))
                        if(woundArea[dx][dy]!=1) woundArea[dx][dy] = -1;
                }

            for(_x = x,_y = y; woundArea[_x][_y]==1; _x -= xkl, _y -= ykl)
                for(int i=0;i<8;i++){
                    dx = _x + d[i][0];
                    dy = _y + d[i][1];
                    if((dx >= 0)&&(dx < 10)&&(dy >= 0)&&(dy < 10))
                        if(woundArea[dx][dy]!=1) woundArea[dx][dy] = -1;
                }
            ships++;
            return 2;
        }else{
            return 1;
        }
    }else{
        woundArea[x][y] = -1;
        return -1;
    }
}
void Player::writeShoot(int b){
    /* -1 - ������, 1 - �����, 2 - ���� */
    if(b==1){
        shootArea[X][Y] = 1;
        if(X+1<10 && Y+1<10) shootArea[X+1][Y+1]=-1;
        if(X+1<10 && Y-1>=0) shootArea[X+1][Y-1]=-1;
        if(X-1>=0 && Y+1<10) shootArea[X-1][Y+1]=-1;
        if(X-1>=0 && Y-1>=0) shootArea[X-1][Y-1]=-1;
        lastMove = true;
    }else if(b==2){
        shootArea[X][Y] = 1;
        int xkl = (shootArea[X+1][Y]==1 || shootArea[X-1][Y]==1?1:0),
            ykl = 1 - xkl,
            _x(X),
            _y(Y),
            dx, dy,
            d[8][2] = {{0,1},{1,0},{0,-1},{-1,0},{1,1},{-1,1},{1,-1},{-1,-1}};
        for(;shootArea[_x][_y]==1;_x += xkl, _y += ykl)
            for(int i=0;i<8;i++){
                dx = _x + d[i][0];
                dy = _y + d[i][1];
                if((dx >= 0)&&(dx < 10)&&(dy >= 0)&&(dy < 10))
                    if(shootArea[dx][dy]!=1) shootArea[dx][dy] = -1;
            }

        for(_x=X,_y=Y; shootArea[_x][_y]==1; _x -= xkl, _y -= ykl)
            for(int i=0;i<8;i++){
                dx = _x + d[i][0];
                dy = _y + d[i][1];
                if((dx >= 0)&&(dx < 10)&&(dy >= 0)&&(dy < 10))
                    if(shootArea[dx][dy]!=1) shootArea[dx][dy] = -1;
            }
        lastMove = false;
    }else{
        shootArea[X][Y] = -1;
        lastMove = false;
    }
}


class Game{
    Player *user, *bot;
    int player;  /* 0 -user, 1 - AI */
public:
    Game(Player &, Player &);
    int whoGoes();
    bool playerMove();
};

Game::Game(Player &_user, Player &_bot):user(&_user),bot(&_bot),player(0){
    user->genNew();
}

int Game::whoGoes(){
    return player;
}
bool Game::playerMove(){
    int b;
    if(!user->gameOver() && !bot->gameOver()){
        if(player==0){
            auto coord = user->shoot(); // pair<int, int>
            b = bot->checkHit(coord.first, coord.second); //  -1 - miss, 1 - hit, 2 - kill
            user->writeShoot(b);
            if(b==-1) player = 1;
        }else if(player==1){
            auto coord = bot->shoot(); // pair<int, int>
            b = user->checkHit(coord.first, coord.second); //  -1 - miss, 1 - hit, 2 - kill
            bot->writeShoot(b);
            if(b==-1) player = 0;
        }
        return true;
    }
    return false;
}


/* system setting vars */
int cellSize = 20;
int xCell = 25;
int yCell = 28;
int width = xCell*cellSize;
int height = yCell*cellSize;
int speed = 1;
bool multithreading = true;

Player one, two;
Game game(one, two);
/* window procedure */
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance, //handle of the application
    HINSTANCE hPrevInstance,
    LPSTR, int nCmdShow)
{
    MSG messages;        /* for messages queue manipulation */
    WNDCLASSEX WndClass; /* data struct for window class */
    HWND hWnd;           /* handle for window */

    /* define window class */
    WndClass.cbSize = sizeof(WNDCLASSEX);
    WndClass.style = CS_DBLCLKS;
    WndClass.hInstance = hInstance;
    WndClass.lpszClassName = "WindowClassName";
    WndClass.lpfnWndProc = WndProc;

    /* icons, cursor and menu */
    WndClass.hIcon = LoadIcon(hInstance, "MAINICON"); /* default icon */
    WndClass.hIconSm = LoadIcon(hInstance, "MAINICON"); /* default icon */
    WndClass.hCursor = LoadCursor(NULL, IDC_ARROW); /* cursor */
    WndClass.lpszMenuName = NULL; /* no menu */
    WndClass.cbClsExtra = 0;
    WndClass.cbWndExtra = 0;

    /* window background color */
    WndClass.hbrBackground = GetSysColorBrush(COLOR_BTNFACE);
    RegisterClassEx(&WndClass);
    hWnd = CreateWindowEx(0,                     /* extended window style */
                          "WindowClassName",     /* registered class */
                          "������� ���", /* window title */
                          (WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX),   /* default window style */
                          CW_USEDEFAULT,         /* x position */
                          CW_USEDEFAULT,         /* y position */
                          width,                   /* width of window */
                          height,                   /* heigth of window */
                          HWND_DESKTOP,          /* The window is a child-window to desktop */
                          NULL,                  /* no menu */
                          hInstance,                 /* Program Instance handler */
                          NULL);                 /* No Window Creation data */

    ShowWindow(hWnd, SW_SHOW);
    UpdateWindow(hWnd);

    /* loop messages. run until GetMessage return 0*/
    while (GetMessage(&messages, NULL, 0, 0))
    {
        TranslateMessage(&messages); /* translate virtual keys into character messages*/
        DispatchMessage(&messages);  /* Send message to WndProc */
    }
    /* return value to system */
    return static_cast<int>(messages.wParam);
}

void drawLine(HDC);
void drawText(HDC, string, int, int);
void drawArea(HDC);
void drawCell(HDC, int, int, int);
void drawPoint(HDC, int, int, int);
void drawCross(HDC, int, int, int);
std::vector<std::pair<int, int> > mas;
UINT TimerId;
std::future<bool> fut; /* for asynchrony */
/*  This function is called by the Windows function DispatchMessage()  */
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    HDC hDC, memDC;
    HBITMAP hScreen, oldBtm;
    int xPos = 0, yPos = 0;
    switch (message)
    {
    case WM_KEYDOWN:
        switch(wParam) {
        case 27: /* Key Esc */
            PostQuitMessage(0);
            break;
        case 96: /* NumPad 0 */
            one = Player(); two = Player();
            Sleep(1000);
            one.genNew();
            TimerId = SetTimer(hwnd, 2, speed, NULL);
            break;
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0); /* send a WM_QUIT to the message queue */
        break;
    case WM_CREATE:
        SetTimer(hwnd, 1, 100, NULL);
        TimerId = SetTimer(hwnd, 2, speed, NULL);
        one.genNew();
        Sleep(1000);
        two.genNew();
        break;
    case WM_TIMER:
        switch (wParam)
        {
            case 2:
                /* Test multithreading and asynchrony */
                if(multithreading){
                    fut = std::async([&](){
                            if(!game.playerMove()){
                                KillTimer(hwnd, TimerId);
                                return true;
                            }else return false;
                            });
                    fut.get();
                }else
                    if(!game.playerMove()) KillTimer(hwnd, TimerId);
                break;
            case 1:
                hDC = GetDC(hwnd);

                memDC = CreateCompatibleDC(hDC);
                hScreen = CreateCompatibleBitmap(hDC, width, height);
                oldBtm = static_cast<HBITMAP>(SelectObject(memDC, hScreen));
                PatBlt(memDC, 0, 0, width, height, WHITENESS);

                drawArea(memDC);

                for(int i=0; i<10; i++)
                    for(int j=0; j<10; j++) {
                        if(one.checkCell(i,j)) drawCell(memDC, i+1, j+1, 1);

                        if(one.getShootCell(i, j)==-1) drawPoint(memDC, i+1, j+1, 2);
                        else if(one.getShootCell(i, j)==1) drawCross(memDC, i+1, j+1, 2);
                        if(one.getWoundCell(i, j)==-1) drawPoint(memDC, i+1, j+1, 1);
                        else if(one.getWoundCell(i, j)==1) drawCross(memDC, i+1, j+1, 1);

                        if(two.checkCell(i,j)) drawCell(memDC, i+1, j+1, 4);

                        if(two.getShootCell(i, j)==-1) drawPoint(memDC, i+1, j+1, 3);
                        else if(two.getShootCell(i, j)==1) drawCross(memDC, i+1, j+1, 3);
                        if(two.getWoundCell(i, j)==-1) drawPoint(memDC, i+1, j+1, 4);
                        else if(two.getWoundCell(i, j)==1) drawCross(memDC, i+1, j+1, 4);

                    }
                    if(one.gameOver() || two.gameOver()){
                    if(one.counter>two.counter) drawText(memDC, "����������", xCell/2*cellSize, 2);
                    if(one.counter<two.counter) drawText(memDC, "����������", xCell/2*cellSize, 13*cellSize);
                    }

                BitBlt(hDC, 0, 0, width, height, memDC, 0, 0, SRCCOPY);
                SelectObject(memDC, oldBtm);
                DeleteObject(hScreen);
                DeleteDC(memDC);
                ReleaseDC(hwnd, hDC);
                break;
        }
        break;
    default:                /* for messages that we don't deal with */
        return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}
void drawText(HDC hDC, string str, int x, int y) { //��������� ������
    SetBkMode(hDC, TRANSPARENT);
    TextOut(hDC, x, y, str.c_str(), static_cast<int>(str.length()));
}
void drawCell(HDC hDC, int x, int y, int k) { //��������� ������
    HBRUSH hBrush = CreateSolidBrush(clBackgroundColor);
    HPEN hPen = CreatePen(PS_SOLID, 3, clBoxLineColor);
    HBRUSH hOldBrush = static_cast<HBRUSH>(SelectObject(hDC, hBrush));
    HPEN hOldPen = static_cast<HPEN>(SelectObject(hDC, hPen));

    if(k==1) Rectangle(hDC, x*cellSize, y*cellSize+cellSize, x*cellSize+cellSize+1, y*cellSize+cellSize*2+1);
    if(k==4) Rectangle(hDC, 13*cellSize+x*cellSize, y*cellSize+14*cellSize, x*cellSize+14*cellSize+1, y*cellSize+cellSize*15+1);

    SelectObject(hDC, hOldBrush);
    SelectObject(hDC, hOldPen);
    DeleteObject(hBrush);
    DeleteObject(hPen);
}
void drawPoint(HDC hDC, int x, int y, int k) { //��������� �����
    HPEN hPen = CreatePen(PS_SOLID, 3, clRedColor);
    HPEN hOldPen = static_cast<HPEN>(SelectObject(hDC, hPen));

    if(k==1) Ellipse(hDC, 0.46*cellSize+x*cellSize, y*cellSize+cellSize*1.46, 0.54*cellSize+x*cellSize+1, y*cellSize+cellSize*1.54+1);
    if(k==2) Ellipse(hDC, 13.46*cellSize+x*cellSize, y*cellSize+cellSize*1.46, 13.54*cellSize+x*cellSize+1, y*cellSize+cellSize*1.54+1);
    if(k==3) Ellipse(hDC, 0.46*cellSize+x*cellSize, y*cellSize+cellSize*14.46, 0.54*cellSize+x*cellSize+1, y*cellSize+cellSize*14.54+1);
    if(k==4) Ellipse(hDC, 13.46*cellSize+x*cellSize, y*cellSize+cellSize*14.46, 13.54*cellSize+x*cellSize+1, y*cellSize+cellSize*14.54+1);

    SelectObject(hDC, hOldPen);
    DeleteObject(hPen);
}
void drawCross(HDC hDC, int x, int y, int k) { //��������� ������
    HPEN hPen = CreatePen(PS_SOLID, 2, clRedColor);
    HPEN hOldPen = static_cast<HPEN>(SelectObject(hDC, hPen));

    if(k==1) {
        MoveToEx(hDC, x*cellSize+2, y*cellSize+cellSize+2, NULL);
        LineTo(hDC, x*cellSize+cellSize-2, y*cellSize+cellSize*2-2);
        MoveToEx(hDC, x*cellSize+cellSize-2, y*cellSize+cellSize+2, NULL);
        LineTo(hDC, x*cellSize+2, y*cellSize+cellSize*2-2);
    } else if(k==2) {
        MoveToEx(hDC, 13*cellSize+x*cellSize+2, y*cellSize+cellSize+2, NULL);
        LineTo(hDC, x*cellSize+14*cellSize-2,  y*cellSize+cellSize*2-2);
        MoveToEx(hDC, 14*cellSize+x*cellSize-2, y*cellSize+cellSize+2, NULL);
        LineTo(hDC, 13*cellSize+x*cellSize+2, y*cellSize+cellSize*2-2);
    }else if(k==3) {
        MoveToEx(hDC, x*cellSize+2, y*cellSize+14*cellSize+2, NULL);
        LineTo(hDC, x*cellSize+cellSize-2, y*cellSize+cellSize*15-2);
        MoveToEx(hDC, x*cellSize+cellSize-2, y*cellSize+14*cellSize+2, NULL);
        LineTo(hDC, x*cellSize+2, y*cellSize+cellSize*15-2);
    } else if(k==4) {
        MoveToEx(hDC, 13*cellSize+x*cellSize+2, y*cellSize+14*cellSize+2, NULL);
        LineTo(hDC, x*cellSize+14*cellSize-2,  y*cellSize+cellSize*15-2);
        MoveToEx(hDC, 14*cellSize+x*cellSize-2, y*cellSize+14*cellSize+2, NULL);
        LineTo(hDC, 13*cellSize+x*cellSize+2, y*cellSize+cellSize*15-2);
    }

    SelectObject(hDC, hOldPen);
    DeleteObject(hPen);
}
void drawArea(HDC hDC) { //��������� ������� ��������
    drawLine(hDC);

    HPEN hPen = CreatePen(PS_SOLID, 3, clBoxLineColor);
    HPEN hOldPen = static_cast<HPEN>(SelectObject(hDC, hPen));
    HBRUSH hOldBrush = static_cast<HBRUSH>(SelectObject(hDC, GetStockBrush(NULL_BRUSH)));

    /* First Box */
    Rectangle(hDC, cellSize, 2*cellSize, 11*cellSize+1, 12*cellSize+1);
    for(int i=1; i<=10; i++) {
        drawText(hDC, string(1,static_cast<char>(64+i)), cellSize*i+3, cellSize+2);
        drawText(hDC, to_string(i), 2, cellSize*(i+1)+2);
    }

    /* Second Box */
    Rectangle(hDC, 14*cellSize, 2*cellSize, 24*cellSize+1, 12*cellSize+1);
    for(int i=1; i<=10; i++) {
        drawText(hDC, string(1,static_cast<char>(64+i)), cellSize*13+cellSize*i+3, cellSize+2);
        drawText(hDC, to_string(i), cellSize*13+2, cellSize*(i+1)+2);
    }

    /* Third Box */
    Rectangle(hDC, cellSize, 15*cellSize, 11*cellSize+1, 25*cellSize+1);
    for(int i=1; i<=10; i++) {
        drawText(hDC, string(1,static_cast<char>(64+i)), cellSize*i+3, 14*cellSize+2);
        drawText(hDC, to_string(i), 2, cellSize*(i+14)+2);
    }

    /* Fourth Box */
    Rectangle(hDC, 14*cellSize, 15*cellSize, 24*cellSize+1, 25*cellSize+1);
    for(int i=1; i<=10; i++) {
        drawText(hDC, string(1,static_cast<char>(64+i)), cellSize*13+cellSize*i+3, 14*cellSize+2);
        drawText(hDC, to_string(i), cellSize*13+2, cellSize*(i+14)+2);
    }

    SelectObject(hDC, hOldBrush);
    SelectObject(hDC, hOldPen);
    DeleteObject(hPen);
}
void drawLine(HDC hDC) { //��������� �����
    HBRUSH hBrush = CreateSolidBrush(clBackgroundColor);
    HBRUSH hOldBrush = static_cast<HBRUSH>(SelectObject(hDC, hBrush));

    /* Draw all window */
    Rectangle(hDC, 0, 0, width, height);

    SelectObject(hDC, hOldBrush);
    DeleteObject(hBrush);

    HPEN hPen = CreatePen(PS_SOLID, 1, clLineColor);
    HPEN hOldPen = static_cast<HPEN>(SelectObject(hDC, hPen));

    /* Horizontal lines */
    for(int i=0; i<xCell; i++)
    {
        MoveToEx(hDC, i*cellSize, cellSize, NULL);
        LineTo(hDC, i*cellSize, height);
    }
    /* Vertical lines */
    for(int i=0; i<yCell; i++)
    {
        MoveToEx(hDC, 0, i*cellSize, NULL);
        LineTo(hDC, width, i*cellSize);
    }

    SelectObject(hDC, hOldPen);
    DeleteObject(hPen);
}
