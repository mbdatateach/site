// (c) Infocatcher 2009-2010 
// version 0.2.6 - 2010-09-18 

// Set extension manually for Coder plugin 
// Call("Scripts::Main", 1, "highlighter.js", "") 
//   - ask user for extension 
// Call("Scripts::Main", 1, "highlighter.js", "html") 
//   - use "html" 

var hlMultipleSets = { 
    //= extension: { 
    //=     subExtension0: [[ext0_startMask0, ext0_endMask0], [ext0_startMask1, ext0_endMask1]], 
    //=     subExtension1: [[ext1_startMask0, ext1_endMask0]] 
    //= } 
    // Or 
    //= otherExtension: "extension" 
    //= "extension" must be already defined! 
    // Masks is case unsensitive. 
    html: { 
        js: [["<script", "</script>"]], 
        css: [["<style", "</style>"]], 
        php: [["<?php", "?>"], ["<?", "?>"]] 
    }, 
    xhtml: "html", 
    htm: "html", 
    php: "html", 
    xml: { 
        js: [ 
            ["<script", "</script>"], 
            ["<![cdata[", "]]>"], 
            ["<constructor>", "</constructor>"], 
            ["<destructor>", "</destructor>"], 
            ["<getter>", "</getter>"], 
            ["<setter>", "</setter>"], 
            ["<field", "</field>"], 
            ["<method", "</method>"], 
            ["<handler", "</handler>"] 
        ], 
        css: [["<style", "</style>"]], 
        php: [["<?php", "?>"], ["<?", "?>"]] 
    }, 
    xul: "xml", 
    xbl: "xml" 
}; 

//var AkelPad = new ActiveXObject("AkelPad.document"); 
var hMainWnd = AkelPad.GetMainWnd(); 
var hWndEdit = AkelPad.GetEditWnd(); 
var oSys = AkelPad.SystemFunction(); 
var fullText; 

var locale = { 
    lng: null, 
    strings: { 
        extRequired: { 
            ru: "��������� ����������: ", 
            en: "Syntax highlighting: " 
        } 
    }, 
    getStr: function(name) { 
        if(!this.lng) { 
            var nLangID = oSys.Call("kernel32::GetUserDefaultLangID"); 
            nLangID = nLangID & 0x3ff; //PRIMARYLANGID 
            switch(nLangID) { 
                case 0x19: this.lng = "ru"; break; 
                default:   this.lng = "en"; 
            } 
        } 
        return this.strings[name][this.lng]; 
    } 
}; 

if(hMainWnd) { 
    var lpPoint = AkelPad.MemAlloc(8 /*sizeof(POINT)*/, true); 
    if(lpPoint) { 
        setRedraw(hWndEdit, false); 
        var selParams = getSelParams(); 
        AkelPad.SendMessage(hWndEdit, 1245 /*EM_GETSCROLLPOS*/, 0, lpPoint); 

        var ext = getExt(hlMultipleSets, selParams); 
        if(ext) { 
            //AkelPad.IsPluginRunning("HighLight::Main")    && AkelPad.Call("HighLight::Main", 1, ext); 
            //AkelPad.IsPluginRunning("AutoComplete::Main") && AkelPad.Call("AutoComplete::Main", 1, ext); 
            //AkelPad.IsPluginRunning("CodeFold::Main")     && AkelPad.Call("CodeFold::Main", 1, ext); 
            if( 
                AkelPad.IsPluginRunning("Coder::HighLight") 
                || AkelPad.IsPluginRunning("Coder::AutoComplete") 
                || AkelPad.IsPluginRunning("Coder::CodeFold") 
            ) 
                AkelPad.Call("Coder::Settings", 1, ext); 
        } 

        AkelPad.SendMessage(hWndEdit, 1246 /*EM_SETSCROLLPOS*/, 0, lpPoint); 
        restoreSelParams(selParams); 
        setRedraw(hWndEdit, true); 
        AkelPad.MemFree(lpPoint, true); 
    } 
} 

function getExt(multiSets, selParams) { 
    if(WScript.Arguments.length) 
        return WScript.Arguments(0); 
    var ext = AkelPad.InputBox( 
        hMainWnd, WScript.ScriptName, 
        locale.getStr("extRequired"), 
        getCurrentExt(multiSets, selParams) || regVal("lastExt") // current or last used extension 
    ); 
    if(!ext) 
        return ""; 
    ext = ext.toLowerCase(); 
    regVal("lastExt", ext); 
    return ext; 
} 
function getCurrentExt(multiSets, selParams) { 
    var cFile = AkelPad.GetEditFile(0); 
    var ext = cFile && /\.([^.]+)$/i.test(cFile) && RegExp.$1.toLowerCase(); 
    if( 
        (ext == "coder" || ext == "highlight" || ext == "autocomplete" || ext == "codefold") 
        && /[\n\r]Extensions:[\n\r]+(;[^\n\r]*[\n\r]+)*([^\s.]+)[\n\r]/.test(getFullText()) 
    ) 
        return RegExp.$2; 
    else if(ext == "txt" && /log/i.test(cFile)) 
        return "log"; 
    var mSet = ext && getParams(multiSets, ext); 
    var _ext = mSet && defineExt(mSet, selParams); 
    return _ext || ext || ""; 
} 
function getParams(sets, key) { 
    var params = sets[key]; 
    if(typeof params == "string") 
        params = sets[params]; 
    return params; 
} 
function defineExt(mSet, selParams) { 
    var fText = getFullText(); 
    var startText = fText.substring(0, selParams[0]).toLowerCase(); 
    var selText = fText.substring(selParams[0], selParams[1]).toLowerCase(); 
    var endText = fText.substring(selParams[1], fText.length).toLowerCase(); 
    var i, start, end, startIndx, endIndx; 
    var mParams; 
    for(var ext in mSet) { 
        mParams = mSet[ext]; 
        for(i = 0, len = mParams.length; i < len; i++) { 
            start = mParams[i][0]; 
            end = mParams[i][1]; 
            startIndx = endText.indexOf(start); 
            endIndx = endText.indexOf(end); 
            if( 
                startText.lastIndexOf(start) > startText.lastIndexOf(end) 
                && (selText.indexOf(start) == -1) && (selText.indexOf(end) == -1) 
                && endIndx != -1 
                && (startIndx == -1 || endIndx < startIndx) 
            ) 
                return ext; 
        } 
    } 
    return ""; 
} 
function getFullText() { 
    if(fullText) 
        return fullText; 
    AkelPad.SetSel(0, -1); 
    return fullText = AkelPad.GetSelText(); 
} 

function setRedraw(hWnd, bRedraw) { 
    AkelPad.SendMessage(hWnd, 11 /*WM_SETREDRAW*/, bRedraw, 0); 
    if(bRedraw) 
        oSys.Call("user32::InvalidateRect", hWnd, 0, true); 
} 
function getSelParams() { 
    return [AkelPad.GetSelStart(), AkelPad.GetSelEnd()]; 
} 
function restoreSelParams(selParams) { 
    AkelPad.SetSel(selParams[0], selParams[1]); 
} 
function regVal(name, val) { 
    name = "HKCU\\Software\\Akelsoft\\AkelPad\\Plugs\\Scripts\\highlighter\\" + name; 
    var wss = new ActiveXObject("WScript.shell"); 
    if(arguments.length == 2) 
        return wss.RegWrite(name, val, "REG_SZ"); 
    try { return wss.RegRead(name); } 
    catch(e) { return ""; } 
}