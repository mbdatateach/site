// Insert file name or path and copy to clipboard - 2010-10-31 
// 
// Call("Scripts::Main", 1, "InsertFileNamePath.js", '"1" [optArg]') - file name 
// Call("Scripts::Main", 1, "InsertFileNamePath.js", '"2" [optArg]') - path with file name 
// Call("Scripts::Main", 1, "InsertFileNamePath.js", '"3" [optArg]') - only path 
// 
// Optional argument: 
// optArg = "0" - inserts to the text, not copy to the clipboard (default, can be omitted), 
// optArg = "1" - inserts to the text and copy to the clipboard, 
// optArg = "2" - only copy to the clipboard, do not insert into the text. 
// 
// Can assign shortcut keys, eg: Ctrl+Shift+F, Ctrl+Shift+Alt+F, Shift+Alt+F. 


var hEditWnd = AkelPad.GetEditWnd(); 

if (! hEditWnd) 
  WScript.Quit(); 

var nArg1; 
var nArg2; 

if (WScript.Arguments.length) 
  nArg1 = WScript.Arguments(0); 
if (!((nArg1 == 1) || (nArg1 == 2) || (nArg1 == 3))) 
  WScript.Quit(); 

if (WScript.Arguments.length > 1) 
  nArg2 = WScript.Arguments(1); 
if (!((nArg2 == 1) || (nArg2 == 2))) 
  nArg2 = 0; 

var pFile = AkelPad.GetEditFile(hEditWnd); 


if (pFile.length > 0) 
{ 
  var nSep = pFile.lastIndexOf("\\"); 

  if (nArg1 == 1) 
    pFile = pFile.substr(nSep + 1); 
  else if (nArg1 == 3) 
    pFile = pFile.substr(0, nSep + 1); 

  if ((nArg2 < 2) && !AkelPad.GetEditReadOnly(hEditWnd)) 
    AkelPad.ReplaceSel(pFile, true); 

  if (nArg2 > 0) 
    AkelPad.SetClipboardText(pFile); 
}