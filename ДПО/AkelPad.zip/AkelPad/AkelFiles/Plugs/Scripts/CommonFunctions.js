///Common functions for WinFS 
// Version: 1.3 (2010.08.02) 

//Default �ptions for file dialogs 
var _TCHAR; 
var _TSTR; 
var _TSIZE; 
var pDefaultExt = "txt"; 


//FUNCTIONS 
function FileDialogDefault(bOpenTrueSaveFalse, pInitialFile, pInitialExt) 
{ 
   var hMainWnd = AkelPad.GetMainWnd(); 
    
   if (pInitialFile == '' && WScript.Arguments.length) 
      if (WScript.Arguments(0).indexOf('\\') != -1)      //���� �� ��������� ������ ���� ��� ������ ���� � ����� 
         pInitialFile = WScript.Arguments(0); 
    
   if (pInitialExt != '') 
      pDefaultExt = pInitialExt; 
    
   return FileDialog(bOpenTrueSaveFalse, hMainWnd, pInitialFile, pInitialExt, 1); 
} 

function getFileVariables(hWnd) 
{ 
   var bResult = false; 
    
   if (hWnd) 
   { 
      if (AkelPad.IsOldWindows()) 
      { 
         _TCHAR="A"; 
         _TSTR=0 /*DT_ANSI*/; 
         _TSIZE=1 /*sizeof(char)*/; 
      } 
      else 
      { 
         _TCHAR="W"; 
         _TSTR=1 /*DT_UNICODE*/; 
         _TSIZE=2 /*sizeof(wchar_t)*/; 
      } 
      bResult = true; 
   } 
   return bResult; 
} 

function FileDialog(bOpenTrueSaveFalse, hWnd, pInitialFile, pFilter, nFilterIndex) 
{ 
   var nFlags = 0x880804; //OFN_HIDEREADONLY|OFN_PATHMUSTEXIST|OFN_EXPLORER|OFN_ENABLESIZING 
   var lpStructure; 
   var lpFilterBuffer; 
   var lpFileBuffer; 
   var lpExtBuffer; 
   var oFunction; 
   var nCallResult; 
   var pResultFile = ""; 
    
   if (getFileVariables(hWnd) == true) 
   { 
      if (pFilter == '') 
      { 
         pFilter = "Text files (*.txt)\x00*.txt\x00All Files (*.*)\x00*.*\x00\x00"; 
         nFilterIndex = 2; 
      } 
       
      if (lpFilterBuffer = AkelPad.MemAlloc(256 * _TSIZE)) 
      { 
         AkelPad.MemCopy(lpFilterBuffer, pFilter.substr(0, 255), _TSTR); 
          
         if (lpFileBuffer = AkelPad.MemAlloc(256 * _TSIZE)) 
         { 
            AkelPad.MemCopy(lpFileBuffer, pInitialFile.substr(0, 255), _TSTR); 
             
            if (lpExtBuffer = AkelPad.MemAlloc(256 * _TSIZE)) 
            { 
               AkelPad.MemCopy(lpExtBuffer, pDefaultExt.substr(0, 255), _TSTR); 
                
               if (lpStructure = AkelPad.MemAlloc(76))  //sizeof(OPENFILENAMEA) or sizeof(OPENFILENAMEW) 
               { 
                  //Fill structure 
                  AkelPad.MemCopy(lpStructure, 76, 3   /*DT_DWORD*/);                   //lStructSize 
                  AkelPad.MemCopy(lpStructure + 4, hWnd, 3   /*DT_DWORD*/);             //hwndOwner 
                  AkelPad.MemCopy(lpStructure + 12, lpFilterBuffer, 3   /*DT_DWORD*/);  //lpstrFilter 
                  AkelPad.MemCopy(lpStructure + 24, nFilterIndex, 3   /*DT_DWORD*/);    //nFilterIndex 
                  AkelPad.MemCopy(lpStructure + 28, lpFileBuffer, 3   /*DT_DWORD*/);    //lpstrFile 
                  AkelPad.MemCopy(lpStructure + 32, 256, 3   /*DT_DWORD*/);             //nMaxFile 
                  AkelPad.MemCopy(lpStructure + 52, nFlags, 3   /*DT_DWORD*/);          //Flags 
                  AkelPad.MemCopy(lpStructure + 60, lpExtBuffer, 3   /*DT_DWORD*/);     //lpstrDefExt 
                   
                  if (oFunction = AkelPad.SystemFunction()) 
                  { 
                     //Call dialog 
                     oFunction.AddParameter(lpStructure); 
                     if (bOpenTrueSaveFalse == true) 
                        nCallResult = oFunction.Call("comdlg32::GetOpenFileName" + _TCHAR); 
                     else 
                        nCallResult = oFunction.Call("comdlg32::GetSaveFileName" + _TCHAR); 
                      
                     //Result file 
                     if (nCallResult) pResultFile = AkelPad.MemRead(lpFileBuffer, _TSTR); 
                  } 
                  AkelPad.MemFree(lpStructure); 
               } 
               AkelPad.MemFree(lpExtBuffer); 
            } 
            AkelPad.MemFree(lpFileBuffer); 
         } 
         AkelPad.MemFree(lpFilterBuffer); 
      } 
   } 
   return pResultFile; 
} 



/// SUB FUNCTIONS 

function GetParent(pFile) 
{ 
   var pDir = ""; 
   var pozLastSep = pFile.lastIndexOf('\\'); 
   if (pozLastSep != -1) 
      pDir = pFile.slice(0, pozLastSep); 
   return pDir; 
} 

function GetParentClosed(pFile) 
{ 
   var pDir = GetParent(pFile); 
   if (pDir != '') 
      pDir = pDir + '\\'; 
   return pDir; 
} 

function GetFileName(pFile) 
{ 
   return pFile.slice(pFile.lastIndexOf('\\') + 1); 
} 

//Remove inadmissible symbols (from wisgest) 
function CorrectFileName(pFileNameOnly) 
{ 
   return pFileNameOnly.replace(/[\\\/:\*\?"<>\|]/g, ""); 
} 

function CorrectFileNameFull(pFile) 
{ 
   pFileNameOnly = GetFileName(pFile); 
   pFileNameOnly = CorrectFileName(pFileNameOnly); 
   return GetParent(pFile) + '\\' + pFileNameOnly; 
}