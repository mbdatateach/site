/// Delete record from recent files
//
// Example via ContextMenu plugin:
// Call("Scripts::Main", 1, "DeleteRecentFile.js", `'%f'`)

var hMainWnd=AkelPad.GetMainWnd();

if (WScript.Arguments.length)
  DeleteRecentFile(WScript.Arguments(0));

function DeleteRecentFile(pFileToDelete)
{
  var lpRecentFiles;
  var lpFilesArray;
  var lpPositionsArray;
  var lpCodepagesArray;
  var pFile;
  var nRecentFiles;
  var nNumber;
  var a;
  var b;
  var i;

  if (lpRecentFiles=AkelPad.MemAlloc(_X64?24:12 /*sizeof(RECENTFILES)*/))
  {
    if (nRecentFiles=AkelPad.SendMessage(hMainWnd, 1238 /*AKD_RECENTFILES*/, 1 /*RF_GET*/, lpRecentFiles))
    {
      lpFilesArray=AkelPad.MemRead(lpRecentFiles, 2 /*DT_QWORD*/);
      lpPositionsArray=AkelPad.MemRead(lpRecentFiles + (_X64?8:4), 2 /*DT_QWORD*/);
      lpCodepagesArray=AkelPad.MemRead(lpRecentFiles + (_X64?16:8), 2 /*DT_QWORD*/);

      for (i=0; i < nRecentFiles; ++i)
      {
        if (!(pFile=AkelPad.MemRead(lpFilesArray + i * 520 /*MAX_PATH * sizeof(wchar_t)*/, 1 /*DT_UNICODE*/)))
          break;

        if (pFile == pFileToDelete)
        {
          for (a=i, b=nRecentFiles - 1; a < b; ++a)
          {
            if (!(pFile=AkelPad.MemRead(lpFilesArray + a * 520 /*MAX_PATH * sizeof(wchar_t)*/, 1 /*DT_UNICODE*/)))
              break;

            pFile=AkelPad.MemRead(lpFilesArray + (a + 1) * 520 /*MAX_PATH * sizeof(wchar_t)*/, 1 /*DT_UNICODE*/);
            AkelPad.MemCopy(lpFilesArray + a * 520 /*MAX_PATH * sizeof(wchar_t)*/, pFile, 1 /*DT_UNICODE*/);

            nNumber=AkelPad.MemRead(lpPositionsArray + (a + 1) * 4 /*sizeof(DWORD)*/, 3 /*DT_DWORD*/);
            AkelPad.MemCopy(lpPositionsArray + a * 4 /*sizeof(DWORD)*/, nNumber, 3 /*DT_DWORD*/);

            nNumber=AkelPad.MemRead(lpCodepagesArray + (a + 1) * 4 /*sizeof(DWORD)*/, 3 /*DT_DWORD*/);
            AkelPad.MemCopy(lpCodepagesArray + a * 4 /*sizeof(DWORD)*/, nNumber, 3 /*DT_DWORD*/);
          }
          AkelPad.MemCopy(lpFilesArray + a * 520 /*MAX_PATH * sizeof(wchar_t)*/, "", 1 /*DT_UNICODE*/);
          AkelPad.MemCopy(lpPositionsArray + a * 4 /*sizeof(DWORD)*/, 0, 3 /*DT_DWORD*/);
          AkelPad.MemCopy(lpCodepagesArray + a * 4 /*sizeof(DWORD)*/, 0, 3 /*DT_DWORD*/);

          AkelPad.SendMessage(hMainWnd, 1238 /*AKD_RECENTFILES*/, 4 /*RF_SAVE*/, 0);
          break;
        }
      }
    }
    AkelPad.MemFree(lpRecentFiles);
  }
}