/// Delete empty lines 

var bIgnoreSpaces=true; 
var pSelText; 
var pResult; 

AkelPad.SetSel(0, -1); 
pSelText=AkelPad.GetSelText(); 

if (bIgnoreSpaces) 
  pResult=pSelText.replace(/^[ \t]*$\r*/gm, ""); 
else 
  pResult=pSelText.replace(/\r+/g, "\r"); 

AkelPad.ReplaceSel(pResult);