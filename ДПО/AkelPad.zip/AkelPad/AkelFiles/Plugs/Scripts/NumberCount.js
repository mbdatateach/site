/// Insert numbers in lines 

var AkelPad=new ActiveXObject("AkelPad.document"); 
var WshShell=new ActiveXObject("WScript.Shell"); 

var hMainWnd=AkelPad.GetMainWnd(); 
var hEditWnd=AkelPad.GetEditWnd(); 
var oFunction=AkelPad.SystemFunction(); 
var hWndCurrentEdit=hEditWnd; 

//Wait for release all virtual keys 
AkelPad.SendMessage(hMainWnd, 1178 /*AKD_WAITKEYBOARD*/, 0, 0); 

while (hMainWnd && hWndCurrentEdit) 
{ 
  var nFirstNumber=0;          //First number, can be negative. 
  var nLastNumber=0x7FFFFFFF;          //Last number, can be negative. Max: 0x7FFFFFFF, min: -0x7FFFFFFF. 
  var nStep=1;                 //Step count, can be negative. 
  var nWidth=3;                //Minimum number of characters. 
  var bAllDocuments=false;     //Insert in all documents 
  var sPrefix=""              //Numbers' prefix 

  var nCurrentNumber=nFirstNumber; 
  var pNumberText; 
  var nZero; 
  var hWndForeground; 
  var nCurChar; 
  var nCurLine; 
  var nLineCount; 

  if (bAllDocuments) AkelPad.SetSel(0, 0); 
  else 
  { 
    var sContent=AkelPad.GetSelText(); 
    var nLength=sContent.length; 

    if (nLength>0) 
    { 

      var CH; 
      var Rows=0; 

      for (var i=0;nLength-1>i;i++) 
        Rows+=(sContent.charAt(i)=="\r"); 

      nLastNumber=nFirstNumber+Rows*nStep; 
    } 
  } 

  while (1) 
  { 
    if (nStep < 0) 
    { 
      if (nCurrentNumber < nLastNumber) 
        break; 
    } 
    else if (nStep > 0) 
    { 
      if (nCurrentNumber > nLastNumber) 
        break; 
    } 
    else break; 

    //Add zeros 
    pNumberText=nCurrentNumber.toString(); 
    if (nCurrentNumber < 0) pNumberText=pNumberText.substr(1); 
    nZero=nWidth - pNumberText.length; 

    while (nZero > 0) 
    { 
      pNumberText="0" + pNumberText; 
      --nZero; 
    } 
    if (nCurrentNumber < 0) pNumberText="-" + pNumberText; 

    //Check that foreground window is AkelPad 
    hWndForeground=oFunction.Call("user32::GetForegroundWindow") 

    if (hWndForeground == hMainWnd) 
    { 
      //Insert text 
      WshShell.SendKeys("{HOME}"); 
      AkelPad.ReplaceSel(sPrefix + pNumberText + "         "); 
      WshShell.SendKeys("{DOWN}"); 
    } 
    else break; 

    //Check end of document 
    nCurChar=AkelPad.GetSelEnd(); 
    nCurLine=AkelPad.SendMessage(hWndCurrentEdit, 1078 /*EM_EXLINEFROMCHAR*/, 0, nCurChar) + 1; 
    nLineCount=AkelPad.SendMessage(hWndCurrentEdit, 186 /*EM_GETLINECOUNT*/, 0, 0); 
    if (nLineCount == nCurLine) break; 

    //Next number 
    nCurrentNumber+=nStep; 
  } 

  if (bAllDocuments) 
  { 
    //Next MDI frame 
    AkelPad.SendMessage(hMainWnd, 273 /*WM_COMMAND*/, 4404 /*IDM_NONMENU_MDINEXT*/, 0); 
    hWndCurrentEdit=AkelPad.GetEditWnd(); 
    if (hWndCurrentEdit == hEditWnd) break; 
  } 
  else break; 
}