/// Undo all changes (4.x.x only) 

var hMainWnd=AkelPad.GetMainWnd(); 
var hWndEdit=AkelPad.GetEditWnd(); 
var bAkelEdit=AkelPad.IsAkelEdit(); 

if (hMainWnd) 
{ 
  if (bAkelEdit)
  { 
    while (AkelPad.SendMessage(hWndEdit, 3075 /*AEM_CANUNDO*/, 0, 0)) 
    { 
      if (!AkelPad.SendMessage(hWndEdit, 3086 /*AEM_GETMODIFY*/, 0, 0)) 
        break; 
      AkelPad.SendMessage(hWndEdit, 3077 /*AEM_UNDO*/, 0, 0); 
    } 
  } 
}