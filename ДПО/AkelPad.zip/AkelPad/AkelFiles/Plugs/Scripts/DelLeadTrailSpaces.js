/// Delete leading and trailing spaces 

var pSelText; 
var pResult; 

AkelPad.SetSel(0, -1); 
pSelText=AkelPad.GetSelText(); 
pResult=pSelText.replace(/(^[ \t]+)|([ \t]+$)/gm, ""); 
AkelPad.ReplaceSel(pResult);