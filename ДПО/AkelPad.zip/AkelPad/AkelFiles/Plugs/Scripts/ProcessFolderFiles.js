///Opens all files located in the folder 
// Version: 1.0 (2010.07.29) 

function processFolderFiles(pFilePath, bErrMsg) 
{ 
   if (pFilePath != "") 
   { 
      var fso = new ActiveXObject("Scripting.FileSystemObject"); 
       
      var dir = fso.GetParentFolderName(pFilePath); 
      if (fso.FolderExists(dir)) 
      { 
         var folder = fso.getFolder(dir); 
          
         filescollection = new Enumerator(folder.files); 
          
         for (; !filescollection.atEnd(); filescollection.moveNext()) 
            processFile(filescollection.item()); 
      } 
      else 
      { 
         if (bErrMsg) 
            AkelPad.MessageBox(AkelPad.GetEditWnd(), '����� "' + dir + '" �� ������� �� �����.', "AkelPad -> " + WScript.ScriptName, 0 /*MB_OK*/ + 64 /*MB_ICONINFORMATION*/); 
      } 
   } 
} 


/* 
// user-defined function (copy it to the calling script) 
function processFile(file) 
{ 
   //code 
} 
*/