///Copy to clipboard filename full (with path) 

var objArgs = WScript.Arguments; 
var pFile = objArgs(0); 

if (pFile != '') 
{ 
  var AkelPad = new ActiveXObject("AkelPad.document"); 
  AkelPad.SetClipboardText(pFile); 
}