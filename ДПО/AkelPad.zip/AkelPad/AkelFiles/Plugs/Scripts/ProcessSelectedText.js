function processSelectedText(pSelText) 
{ 
   var arrOutput =[];                                 // output array of strings 
    
   if (pSelText.length > 0) 
   { 
      var arrInput = pSelText.split(/\r\n|\n|\r/);      // input array of strings 
      var numStr = arrInput.length;                     // number of strings 
       
      for (var i = 0; i < numStr; i++) 
      { 
         if (!excludeString(arrInput[i])) 
         { 
            arrOutput[i] = processString(arrInput[i]); // process each string 
         } 
      } 
   } 
    
   return arrOutput; 
} 


/* 
// user-defined function 
function excludeString(s) 
{ 
   // return true to exclude the string s 
   return (s.length == 0); 
} 


// user-defined function 
function processString(s) 
{ 
   // code modify the string s 
   //return pResult; 
} 
*/